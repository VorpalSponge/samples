#pragma once
class Seat_Row
{
public:
	Seat_Row();
	~Seat_Row();
};

