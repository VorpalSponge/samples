#include "Seat_Row.h"



Seat_Row::Seat_Row()
{
}


Seat_Row::~Seat_Row()
{
}
